import React from "react";
import { Image,Avatar, Heading, VStack } from "@chakra-ui/react";
import FullScreenSection from "./FullScreenSection";


const greeting = "Hello, I am Pete!";
const bio1 = "A frontend developer";
const bio2 = "specialised in React";

// Implement the UI for the LandingSection component according to the instructions.
// Use a combination of Avatar, Heading and VStack components.
const LandingSection = () => (
  <FullScreenSection
    justifyContent="center"
    alignItems="center"
    isDarkBackground
    backgroundColor="black"
  >
     <VStack>
      {/* Change here */}
     <Avatar name='Pete' src=' https://i.pravatar.cc/150?img=7' size="2xl" />
     {/* <Image src='https://media-exp1.licdn.com/dms/image/D4D03AQGx2G3efiS3qQ/profile-displayphoto-shrink_800_800/0/1664881316202?e=1675900800&v=beta&t=igThhgxKtg57FySsN-NMIbKk5PUgbg7y8o1f1_WLSs0' boxSize="sm" borderRadius='full'/> */}
     {/* <Heading size="1xs">{greeting}</Heading> */}
     <Heading size="1xs">Hello, I am Pete!</Heading>
     <Heading >{bio1}</Heading>
     <Heading >{bio2}</Heading>
     </VStack>
  </FullScreenSection>
);

export default LandingSection;
