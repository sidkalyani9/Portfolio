import * as React from "react";
import { VStack } from "@chakra-ui/react";
import neon from './neon.jpeg'; 

/**
 * Illustrates the use of children prop and spread operator
 */
const FullScreenSection = ({ children, isDarkBackground, ...boxProps }) => {
  return (
    <VStack
    // Change here
      backgroundColor={boxProps.backgroundColor}
      // bgImage= {neon}
      // backgroundPosition="center"
      // backgroundSize="cover"
      // backgroundRepeat="no-repeat"
      color={isDarkBackground ? "white" : "black"}
    >
      <VStack 
        backgroundBlendMode="color-burn"
        backgroundPosition="center"
        backgroundSize="cover"
        backgroundRepeat="no-repeat"
        maxWidth="1280px" minHeight="100vh" {...boxProps}>
        {children}
      </VStack>
    </VStack>
  );
};

export default FullScreenSection;
